﻿using System;

namespace Hamurabi
{
	public class Debug
	{
		public static void Log(string message)
		{
			Console.WriteLine(message);
		}
	}
}